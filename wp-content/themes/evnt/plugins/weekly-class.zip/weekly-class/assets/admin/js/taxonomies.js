(function($) {
	"use strict";
	
	$(function() {

		$('.wp-color-picker-field').wpColorPicker();
		
	});
	
})(jQuery);