<div class="meta">

<?php the_time( 'M d, Y' ); ?>
</div>
